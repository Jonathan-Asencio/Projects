

public class Constants
{
    public static final int SIZE = 8;
    public static final int NSHIPS = 5;
}
